import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
        contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main Street");
    }

    @Test
    public void testAddContact() {
        assertTrue(contactService.addContact(contact));
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    public void testAddDuplicateContact() {
        assertTrue(contactService.addContact(contact));

        Contact duplicateContact = new Contact("12345", "Jane", "Doe", "0987654321", "456 Oak Street");

        assertFalse(contactService.addContact(duplicateContact));
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    public void testAddNullContact() {
        assertFalse(contactService.addContact(null));
    }

    @Test
    public void testDeleteContact() {
        contactService.addContact(contact);

        assertTrue(contactService.deleteContact("12345"));
        assertNull(contactService.getContact("12345"));
    }

    @Test
    public void testDeleteContactThatDoesNotExist() {
        assertFalse(contactService.deleteContact("99999"));
    }

    @Test
    public void testUpdateFirstName() {
        contactService.addContact(contact);

        assertTrue(contactService.updateFirstName("12345", "Jane"));
        assertEquals("Jane", contactService.getContact("12345").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        contactService.addContact(contact);

        assertTrue(contactService.updateLastName("12345", "Doe"));
        assertEquals("Doe", contactService.getContact("12345").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        contactService.addContact(contact);

        assertTrue(contactService.updatePhone("12345", "0987654321"));
        assertEquals("0987654321", contactService.getContact("12345").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        contactService.addContact(contact);

        assertTrue(contactService.updateAddress("12345", "456 Oak Street"));
        assertEquals("456 Oak Street", contactService.getContact("12345").getAddress());
    }

    @Test
    public void testUpdateContactThatDoesNotExist() {
        assertFalse(contactService.updateFirstName("99999", "Jane"));
        assertFalse(contactService.updateLastName("99999", "Doe"));
        assertFalse(contactService.updatePhone("99999", "0987654321"));
        assertFalse(contactService.updateAddress("99999", "456 Oak Street"));
    }

    @Test
    public void testUpdateFirstNameWithInvalidValue() {
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateFirstName("12345", "TooLongName1");
        });
    }

    @Test
    public void testUpdateLastNameWithInvalidValue() {
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateLastName("12345", "TooLongName1");
        });
    }

    @Test
    public void testUpdatePhoneWithInvalidValue() {
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updatePhone("12345", "12345");
        });
    }

    @Test
    public void testUpdateAddressWithInvalidValue() {
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateAddress("12345", "1234567890123456789012345678901");
        });
    }
}
