package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
    private AppointmentService appointmentService;

    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    void testAddAppointmentWithUniqueId() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");

        appointmentService.addAppointment(appointment);

        assertEquals(appointment, appointmentService.getAppointment("12345"));
    }

    @Test
    void testCannotAddDuplicateAppointmentId() {
        Appointment appointmentOne = new Appointment("12345", getFutureDate(), "Doctor visit");
        Appointment appointmentTwo = new Appointment("12345", getFutureDate(), "Dentist visit");

        appointmentService.addAppointment(appointmentOne);

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointmentTwo);
        });
    }

    @Test
    void testCannotAddNullAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(null);
        });
    }

    @Test
    void testDeleteAppointmentById() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");
        appointmentService.addAppointment(appointment);

        appointmentService.deleteAppointment("12345");

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.getAppointment("12345");
        });
    }

    @Test
    void testCannotDeleteAppointmentThatDoesNotExist() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("99999");
        });
    }

    @Test
    void testUpdateAppointmentDate() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");
        Date newDate = new Date(System.currentTimeMillis() + 172800000);
        appointmentService.addAppointment(appointment);

        appointmentService.updateAppointmentDate("12345", newDate);

        assertEquals(newDate, appointmentService.getAppointment("12345").getAppointmentDate());
    }

    @Test
    void testCannotUpdateAppointmentDateForUnknownId() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.updateAppointmentDate("99999", getFutureDate());
        });
    }

    @Test
    void testCannotUpdateAppointmentDateToNull() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");
        appointmentService.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.updateAppointmentDate("12345", null);
        });
    }

    @Test
    void testUpdateDescription() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");
        appointmentService.addAppointment(appointment);

        appointmentService.updateDescription("12345", "Updated appointment");

        assertEquals("Updated appointment", appointmentService.getAppointment("12345").getDescription());
    }

    @Test
    void testCannotUpdateDescriptionForUnknownId() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.updateDescription("99999", "Updated appointment");
        });
    }

    @Test
    void testCannotUpdateDescriptionToLongValue() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");
        appointmentService.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.updateDescription("12345", "This description is longer than fifty characters total.");
        });
    }
}
