package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentTest {

    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    private Date getPastDate() {
        return new Date(System.currentTimeMillis() - 86400000);
    }

    @Test
    void testAppointmentCreatedSuccessfully() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals("Doctor visit", appointment.getDescription());
        assertNotNull(appointment.getAppointmentDate());
    }

    @Test
    void testAppointmentIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Doctor visit");
        });
    }

    @Test
    void testAppointmentIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Doctor visit");
        });
    }

    @Test
    void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Doctor visit");
        });
    }

    @Test
    void testAppointmentDateCannotBeInThePast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getPastDate(), "Doctor visit");
        });
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getFutureDate(), null);
        });
    }

    @Test
    void testDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getFutureDate(), "This description is longer than fifty characters total.");
        });
    }

    @Test
    void testStoredAppointmentDateCannotBeChangedExternally() {
        Date appointmentDate = getFutureDate();
        Appointment appointment = new Appointment("12345", appointmentDate, "Doctor visit");

        appointmentDate.setTime(getPastDate().getTime());

        assertFalse(appointment.getAppointmentDate().before(new Date()));
    }

    @Test
    void testReturnedAppointmentDateCannotChangeAppointment() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");
        Date returnedDate = appointment.getAppointmentDate();

        returnedDate.setTime(getPastDate().getTime());

        assertFalse(appointment.getAppointmentDate().before(new Date()));
    }

    @Test
    void testDescriptionCanBeUpdated() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");
        appointment.setDescription("Dentist appointment");

        assertEquals("Dentist appointment", appointment.getDescription());
    }

    @Test
    void testAppointmentDateCanBeUpdated() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");
        Date newDate = new Date(System.currentTimeMillis() + 172800000);
        appointment.setAppointmentDate(newDate);

        assertEquals(newDate, appointment.getAppointmentDate());
    }

    @Test
    void testAppointmentDateCannotBeUpdatedToNull() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(null);
        });
    }

    @Test
    void testAppointmentDateCannotBeUpdatedToPastDate() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(getPastDate());
        });
    }

    @Test
    void testDescriptionCannotBeUpdatedToNull() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
    }

    @Test
    void testDescriptionCannotBeUpdatedToLongValue() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("This description is longer than fifty characters total.");
        });
    }
}
