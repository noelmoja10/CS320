import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public boolean addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            return false;
        }

        tasks.put(task.getTaskId(), task);
        return true;
    }

    public boolean deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            return false;
        }

        tasks.remove(taskId);
        return true;
    }

    public boolean updateName(String taskId, String name) {
        Task task = tasks.get(taskId);

        if (task == null) {
            return false;
        }

        task.setName(name);
        return true;
    }

    public boolean updateDescription(String taskId, String description) {
        Task task = tasks.get(taskId);

        if (task == null) {
            return false;
        }

        task.setDescription(description);
        return true;
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
