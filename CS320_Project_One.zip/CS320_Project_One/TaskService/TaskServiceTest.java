import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;
    private Task task;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
        task = new Task("12345", "Task Name", "Valid description");
    }

    @Test
    public void testAddTask() {
        assertTrue(taskService.addTask(task));
        assertEquals(task, taskService.getTask("12345"));
    }

    @Test
    public void testAddDuplicateTask() {
        assertTrue(taskService.addTask(task));

        Task duplicateTask = new Task("12345", "Other Task", "Another description");

        assertFalse(taskService.addTask(duplicateTask));
    }

    @Test
    public void testAddNullTask() {
        assertFalse(taskService.addTask(null));
    }

    @Test
    public void testDeleteTask() {
        taskService.addTask(task);

        assertTrue(taskService.deleteTask("12345"));
        assertNull(taskService.getTask("12345"));
    }

    @Test
    public void testDeleteTaskThatDoesNotExist() {
        assertFalse(taskService.deleteTask("99999"));
    }

    @Test
    public void testUpdateName() {
        taskService.addTask(task);

        assertTrue(taskService.updateName("12345", "New Name"));
        assertEquals("New Name", taskService.getTask("12345").getName());
    }

    @Test
    public void testUpdateDescription() {
        taskService.addTask(task);

        assertTrue(taskService.updateDescription("12345", "New description"));
        assertEquals("New description", taskService.getTask("12345").getDescription());
    }

    @Test
    public void testUpdateTaskThatDoesNotExist() {
        assertFalse(taskService.updateName("99999", "New Name"));
        assertFalse(taskService.updateDescription("99999", "New description"));
    }

    @Test
    public void testUpdateNameWithInvalidValue() {
        taskService.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateName("12345", "This name is way too long");
        });
    }

    @Test
    public void testUpdateDescriptionWithInvalidValue() {
        taskService.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateDescription("12345", "This description is longer than fifty characters and should fail.");
        });
    }
}
