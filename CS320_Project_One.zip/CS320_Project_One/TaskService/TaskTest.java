import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreatedSuccessfully() {
        Task task = new Task("1234567890", "Task Name", "This is a valid task description.");

        assertEquals("1234567890", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("This is a valid task description.", task.getDescription());
    }

    @Test
    public void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "Valid description");
        });
    }

    @Test
    public void testTaskIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "Valid description");
        });
    }

    @Test
    public void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This name is way too long", "Valid description");
        });
    }

    @Test
    public void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Valid description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Task Name", "This description is longer than fifty characters and should fail.");
        });
    }

    @Test
    public void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Task Name", null);
        });
    }

    @Test
    public void testUpdateNameSuccessfully() {
        Task task = new Task("12345", "Old Name", "Valid description");
        task.setName("New Name");

        assertEquals("New Name", task.getName());
    }

    @Test
    public void testUpdateDescriptionSuccessfully() {
        Task task = new Task("12345", "Task Name", "Old description");
        task.setDescription("New description");

        assertEquals("New description", task.getDescription());
    }

    @Test
    public void testUpdateNameWithInvalidValue() {
        Task task = new Task("12345", "Task Name", "Valid description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("This name is way too long");
        });
    }

    @Test
    public void testUpdateNameWithNullValue() {
        Task task = new Task("12345", "Task Name", "Valid description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
    }

    @Test
    public void testUpdateDescriptionWithInvalidValue() {
        Task task = new Task("12345", "Task Name", "Valid description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This description is longer than fifty characters and should fail.");
        });
    }

    @Test
    public void testUpdateDescriptionWithNullValue() {
        Task task = new Task("12345", "Task Name", "Valid description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
    }
}
